#SERvER

#install
npm install express firebase dotenv cors morgan 
npm i cookie-parser method-override morgan path
npm i nodemon --save-db
npm i body-parser

npm i firebase-tools
#read this document to refer about firebases
https://firebase.google.com/docs/firestore/manage-data/delete-data


https://www.youtube.com/watch?v=F6LEKdQPSiM&list=PLSuzwxF6LC4AGZN8SrPbRkN3MrLWubOGW
https://www.youtube.com/watch?v=T4_16HPoJrI
https://towardsdev.com/firebase-authentication-node-js-using-rest-api-and-async-await-302a568d6470-> basic data struc
https://www.youtube.com/watch?v=29BNaJiqWB4&t=256s




https://firebase.google.com/docs/firestore/quickstart#node.js